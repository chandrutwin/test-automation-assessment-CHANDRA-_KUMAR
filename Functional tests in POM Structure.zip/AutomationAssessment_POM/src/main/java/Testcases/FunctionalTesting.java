package Testcases;

import javax.mail.MessagingException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.EmergencyContacts;
import Pages.Login;
import Steps.AddEmergencyContact;
import Steps.EditProfile;

public class FunctionalTesting {
	static AddEmergencyContact addEmergency = new AddEmergencyContact();
	
	public static void main(String args[]) throws InterruptedException, MessagingException
	{
		testCase1();
		testCase2();
		
	}
	

	public static void testCase1() 
	{
		System.out.println("Functional Test case 1:");
		System.out.println("Description: Add Emergency contact details");
		addEmergency.addEmergencyContact();
	}
	
	public static void testCase2() 
	{
		System.out.println("Functional Test case 2:");
		System.out.println("Description: Edit Personal data ");
		EditProfile edit = new EditProfile();
		edit.editProfile();
		
	}
}


