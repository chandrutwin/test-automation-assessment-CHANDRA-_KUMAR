package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Dashboard {
	
WebDriver driver;
	
	//Constructor that will be automatically called as soon as the object of the class is created
	public Dashboard(WebDriver driver) {
          this.driver = driver;
	}
	
	By myProfile = By.id("myProfileLink");
	By personalTab = By.xpath("(//ul[@class='sidebar-menu'])/li/a");
	By emergencyTab = By.xpath("(//ul[@id='module_Personal_Information'])/li[5]");

	public void navigateToEditProfile()
	{
		driver.findElement(myProfile).click();
	}
	
	public void navigateToEmergencyContact()
	{
		driver.findElement(personalTab).click();
		driver.findElement(emergencyTab).click();		
	}
}

