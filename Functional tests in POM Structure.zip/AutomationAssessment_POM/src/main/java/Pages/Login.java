package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login {
	
WebDriver driver;
	
	//Constructor that will be automatically called as soon as the object of the class is created
	public Login(WebDriver driver) {
          this.driver = driver;
	}
	
	By user = By.id("username");
	By pwd = By.id("password");
	By login = By.xpath("//button[contains(text(),'Log in')]");
	
	public void enterUsername(String username)
	{
		driver.findElement(user).sendKeys(username);
	}
	
	public void enterPassWord(String password)
	{
		driver.findElement(pwd).sendKeys(password);
	}
	
	public void clickLogin()
	{
		driver.findElement(login).click();
	}

}
