package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class EmployeeProfile {
WebDriver driver;
	
	//Constructor that will be automatically called as soon as the object of the class is created
	public EmployeeProfile(WebDriver driver) {
          this.driver = driver;
	}
	By edit = By.xpath("//span[contains(text(),'Edit')]");
	By mName = By.id("middle_name");
	By genderfield = By.xpath("(//div[@class='ant-select-selector'])[2]");
	By genderToSelect = By.xpath("//div[@title='Male']");
//	By enterGenderTab = By.xpath("//div[@class='ant-select-selector'])[2]");
//	By save = By.xpath("//button[@class='ant-modal-close']/span/span");
	By save = By.xpath("//span[contains(text(),'Save')]");

	public void clickEditButton()
	{
		driver.findElement(edit).click();
	}
	
	public void enterMiddleName(String middleName)
	{
		driver.findElement(mName).clear();
		driver.findElement(mName).sendKeys(middleName);
	}
	
	public void selectGender()
	{
		driver.findElement(genderfield).click();
		driver.findElement(genderToSelect).click();
	}
	
	public void SaveUpdatedData()
	{
		//Need to change
		driver.findElement(save).click();
	}
}
