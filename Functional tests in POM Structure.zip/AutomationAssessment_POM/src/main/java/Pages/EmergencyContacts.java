package Pages;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class EmergencyContacts {
	WebDriver driver;	

	public EmergencyContacts(WebDriver driver) {
        this.driver = driver;
	}
	
	By addButton = By.xpath("//button[contains(text(), 'Add New ')]");
	By name = By.xpath("//input[@id='name']");
	By relation = By.id("relationship");  
	By homePhone = By.name("home_phone");
	By workPhone = By.name("work_phone");
	By mobilePhone = By.xpath("//div[@class='controls col-sm-6']//input[@id='mobile_phone']");
	By saveButton = By.xpath("//button[contains(text(), 'Save')]");
	By getUpdatedGender = By.xpath("(//div[@class='ant-descriptions-view'])[2]/table/tbody/tr[1]/td[2]");
	
	public void clickAddButton()
	{
		driver.findElement(addButton).click();
	}
	
	public void enterDetails(By locator, String value)
	{
		driver.findElement(locator).sendKeys(value);
	}
	
	public void enterName(String value)
	{
		driver.findElement(name).sendKeys(value);
	}
	
	public void enterRelation(String value)
	{
		driver.findElement(relation).sendKeys(value);
	}
	
	public void enterhomePhone(String value)
	{
		driver.findElement(homePhone).sendKeys(value);
	}
	
	public void enterworkPhone(String value)
	{
		driver.findElement(workPhone).sendKeys(value);
	}
	
	public void entermobilePhone(String value)
	{
		driver.findElement(mobilePhone).sendKeys(value);
	}
	
	public void saveData()
	{
		driver.findElement(saveButton).click();
	}
}