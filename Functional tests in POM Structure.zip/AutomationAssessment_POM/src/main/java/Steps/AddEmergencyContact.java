package Steps;

import java.util.concurrent.TimeUnit;

import javax.mail.MessagingException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import Pages.Dashboard;
import Pages.EmergencyContacts;
import Pages.Login;


public class AddEmergencyContact {
WebDriver driver;	

	
	public void addEmergencyContact() 
	{

		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver");
		ChromeDriver driver=new ChromeDriver();	
		driver.get("https://icehrm-open.gamonoid.com/");
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		Login log = new Login(driver);
		Dashboard dash = new Dashboard(driver);
		EmergencyContacts emergency = new EmergencyContacts(driver);
		
		log.enterUsername("user1");
		log.enterPassWord("demouserpwd");
		
		log.clickLogin();
		
		dash.navigateToEmergencyContact();
		
		emergency.clickAddButton();
		emergency.enterName("Chandra Kumar");
		emergency.enterRelation("Parent");
		emergency.enterhomePhone("044-224444");
		emergency.enterworkPhone("04142-826171");
		emergency.entermobilePhone("9876543210");
		emergency.saveData();
			
	}
	
	
}

