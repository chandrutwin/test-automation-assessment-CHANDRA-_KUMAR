package Steps;

import java.util.concurrent.TimeUnit;

import javax.mail.MessagingException;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import Pages.Dashboard;
import Pages.EmployeeProfile;
import Pages.Login;

public class EditProfile{
	public void editProfile()
	{
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver");
		ChromeDriver driver=new ChromeDriver();	
		driver.get("https://icehrm-open.gamonoid.com/");
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
		Login log = new Login(driver);
		Dashboard dash = new Dashboard(driver);
		EmployeeProfile employee = new EmployeeProfile(driver);
		
		log.enterUsername("user1");
		log.enterPassWord("demouserpwd");
		
		log.clickLogin();
		
		dash.navigateToEditProfile();
		
		employee.clickEditButton();
		
		employee.enterMiddleName("Chandru");
		employee.selectGender();
		employee.SaveUpdatedData();
		
		
		
	}

}
