package setup;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;

import pages.MethodsPage;
import pages.Utils;

public class BaseSetup {
    protected static Utils util;
    protected MethodsPage page;

    @BeforeMethod(alwaysRun = true)
    @Parameters("browser")
    public void initialize(String browser) {
        util = Utils.getInstance();
        util.setDriver(browser);
        page = new MethodsPage(util.getDriver());
    }

    @AfterMethod(alwaysRun = true)
    public void afterMethod() {
        util.getDriver().quit();
    }
}
