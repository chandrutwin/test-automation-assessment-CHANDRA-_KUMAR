package utils;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import pages.UserDetails;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class JSONFile {
    public static String path = System.getProperty("user.dir");

    public static ArrayList<UserDetails> getValue() throws FileNotFoundException, IOException, ParseException {
        ArrayList<UserDetails> userData = new ArrayList<>();
        JSONParser parser = new JSONParser();
       
            Object obj = parser.parse(new FileReader(path + "\\src\\main\\resources\\users.json"));
            JSONObject jobj = (JSONObject) obj;
            String uName = (String) jobj.get("username");
            String pwd = (String) jobj.get("password");
            userData.add(new UserDetails(uName, pwd));
        return userData;
    }
}