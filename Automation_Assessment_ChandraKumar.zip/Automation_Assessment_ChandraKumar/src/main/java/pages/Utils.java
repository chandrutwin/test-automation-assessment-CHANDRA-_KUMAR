package pages;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Reporter;
import utils.PropertiesFile;

import java.util.concurrent.TimeUnit;

public class Utils {
    private static Utils instance = null;
    ThreadLocal<RemoteWebDriver> webdriver = new ThreadLocal<RemoteWebDriver>();
    PropertiesFile propertiesFile;

    private Utils() {
    }

    public static Utils getInstance() {
        try {
            if (instance == null)
                instance = new Utils();
        } catch (Exception e) {
            Reporter.log("[Error] Driver instance not created");
        }
        return instance;
    }

    public void setDriver(String browser) {
        try {
        if (browser.equals("chrome")) 
        {
            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            ChromeDriver chromedriver = new ChromeDriver(options);
            chromedriver = new ChromeDriver(options);
            chromedriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            chromedriver.manage().window().maximize();
            chromedriver.get(propertiesFile.getProperties("URL"));
            webdriver.set(chromedriver);
        } 
        
        else if (browser.equals("firefox")) 
        {
            WebDriverManager.firefoxdriver().setup();
            FirefoxOptions options = new FirefoxOptions();
            FirefoxDriver firefoxDriver = new FirefoxDriver(options);
            firefoxDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            firefoxDriver.manage().window().maximize();
            firefoxDriver.get(propertiesFile.getProperties("URL"));
            webdriver.set(firefoxDriver);
        }
    } 
        catch (Exception e) 
        {
            System.out.println("Driver has not instantiated " + e.getMessage());
            e.printStackTrace();
        }
    }

    public RemoteWebDriver getDriver() {
        return webdriver.get();
    }
}
