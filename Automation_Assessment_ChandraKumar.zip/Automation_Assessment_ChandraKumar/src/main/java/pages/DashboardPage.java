package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

import pages.MethodsPage;

public class DashboardPage extends MethodsPage {

    @FindBy(xpath = "//li[@class='dropdown messages-menu']//a[@class='dropdown-toggle']//span//span")
    private static WebElement locale;

    @FindBy(xpath = "//a//span[@class='flag-icon flag-icon-un']")
    private static WebElement English;

    @FindBy(xpath = "//a[text()=' Emergency Contacts ']")
    private static WebElement emergencyContacts;
    
    @FindBy(id = "myProfileLink")
    private static WebElement myProfile;
    

    public DashboardPage(RemoteWebDriver driver) {
        super(driver);
    }

    public Class<EmergencyContactsPage> navigateToEmergencyContactsPage() {
        waitForElementToBeInvisible(emergencyContacts);
        click(emergencyContacts);
        return EmergencyContactsPage.class;
    }

    public void changeLocale() {
        click(locale);
        click(English);
    }
    
	public Class<EmployeeProfilePage> navigateToEmployeeProfilePage(){
		waitForElementToBeInvisible(myProfile);
		click(myProfile);
		return EmployeeProfilePage.class;
	}
}
