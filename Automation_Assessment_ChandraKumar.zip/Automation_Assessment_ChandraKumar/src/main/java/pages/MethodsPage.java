package pages;


import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import pages.MethodsPage;

import java.io.File;
import java.io.IOException;

public class MethodsPage {
    static RemoteWebDriver driver;
    int waitTime = 30;
    WebDriverWait wait;
    public static String path = System.getProperty("user.dir");

    public MethodsPage(RemoteWebDriver webdriver) {
        driver = webdriver;
        wait = new WebDriverWait(driver, waitTime);
        PageFactory.initElements(webdriver, this);
    }

    public static void enterText(String textToEnter, WebElement element) {
            element.sendKeys(Keys.BACK_SPACE);
            element.sendKeys(textToEnter);
    }

    public static void setAttribute(WebElement element, String attName, String attValue) {
        driver.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);",
                element, attName, attValue);
    }

    public static void click(WebElement element)
            throws NoSuchElementException, StaleElementReferenceException {
        element.click();
    }

    public boolean waitForElementToBeInvisible(WebElement mobileElement) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        try {
            wait.until(ExpectedConditions.invisibilityOf(mobileElement));

        } catch (TimeoutException | NoSuchElementException e1) {
            return false;
        }
        return true;
    }

    public boolean waitForElementToBePresent(WebElement mobileElement) {
        WebDriverWait wait = new WebDriverWait(driver, 10);
        try {
            wait.until(ExpectedConditions.visibilityOf(mobileElement));
        } catch (TimeoutException | NoSuchElementException e1) {
            return false;
        }
        return true;
    }


    public static String getText(WebElement element) {
        return element.getText();
    }


    protected static void uploadFile(WebElement element, String filePath) {
        element.sendKeys(filePath);
    }


    public static void takeScreenshot(String testName) {
        try {
            TakesScreenshot sc = ((TakesScreenshot) driver);
            File source = sc.getScreenshotAs(OutputType.FILE);
            File destination = new File(path + "\\src\\test\\java\\TestOutput\\Screenshot\\" + testName + ".jpeg");
            FileUtils.copyFile(source, destination);
        }catch (IOException e){
            System.out.println("Exception in method : "+e.getMessage());
        }
    }

    public <TPage extends MethodsPage> TPage getClass(Class<TPage> anyPage) {
        try {
            return anyPage.getDeclaredConstructor(RemoteWebDriver.class).newInstance(driver);
        } catch (Exception e) {
            Reporter.log("The exception is" + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}
