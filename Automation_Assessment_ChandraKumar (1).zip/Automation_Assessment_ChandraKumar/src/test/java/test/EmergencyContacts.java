package test;

import org.testng.Assert;
import org.testng.annotations.*;

import pages.SignInPage;
import setup.BaseSetup;
import static utils.JSONFile.getValue;

@Listeners(test.TestListeners.class)

public class EmergencyContacts extends BaseSetup {

    @Test
    public void addEmergencyContact() {
        String uName = getValue().get(0).getUsername();
        String pwd = getValue().get(0).getPassword();
        Boolean result = page.getClass(SignInPage.class).loginIntoTheApplication(uName, pwd).navigateToEmergencyContactsPage().addContact();
        Assert.assertFalse(result);
    }
}
