package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;

public class SignInPage extends MethodsPage {

    @FindBy(id = "username")
    private static WebElement uname;

    @FindBy(id = "password")
    private static WebElement pwd;

    @FindBy(xpath = "//button[@type='button']")
    private static WebElement login;

    public SignInPage(RemoteWebDriver driver) {
        super(driver);
    }

    public Class<DashboardPage> loginIntoTheApplication(String userName, String userPassword) {
        waitForElementToBeInvisible(uname);
        enterText(userName, uname);
        enterText(userPassword, pwd);
        click(login);
        return DashboardPage.class;
    }
}
