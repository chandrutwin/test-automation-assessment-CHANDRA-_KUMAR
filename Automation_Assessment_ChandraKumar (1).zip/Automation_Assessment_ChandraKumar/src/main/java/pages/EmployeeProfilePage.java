package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import utils.PropertiesFile;

public class EmployeeProfilePage extends MethodsPage{
	 static PropertiesFile propertiesFile;

	    public EmployeeProfilePage(RemoteWebDriver driver) {
	        super(driver);
	    }
	    
	    @FindBy(xpath = "//span[contains(text(),'Edit')]")
	    private static WebElement edit;
	    
	    @FindBy(id = "middle_name")
	    private static WebElement name;
			
	    @FindBy(xpath = "(//div[@class='ant-select-selector'])[2]")
	    private static WebElement genderfield;
			
	    @FindBy(xpath = "//div[@title='Male'] ")
	    private static WebElement genderToSelect;
	    
	    @FindBy(xpath = "//span[contains(text(),'Save')]")
	    private static WebElement saveButton;
			
	   
		public void editProfile() {
			waitForElementToBeInvisible(edit);
			click(edit);
			enterText(propertiesFile.getProperties("middleName"), name);
			click(genderfield);
			click(genderToSelect);
			click(saveButton);
			
		}
}
