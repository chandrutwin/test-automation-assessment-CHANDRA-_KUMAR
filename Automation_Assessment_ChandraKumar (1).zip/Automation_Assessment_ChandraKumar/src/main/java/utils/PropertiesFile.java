package utils;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesFile {
    public static String path = System.getProperty("user.dir");
    public static Properties properties = new Properties();

    public static String getProperties(String propVal) {
        try {
            InputStream ip = new FileInputStream(path + "\\src\\main\\resources\\config.properties");
            properties.load(ip);
        } catch (Exception e) {
            System.out.println("The exception is:" + e.getMessage());
        }
        return properties.getProperty(propVal);
    }
}
